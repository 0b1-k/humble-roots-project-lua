The Humble Roots Project requires six power relays and one solenoid.
These parts can be obtained as off the shelf components are they can be
built using the provided schematics.


